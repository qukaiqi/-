package gzeic.cn;
	import java.io.Serializable;
	public class Student implements Serializable{
		private static final long serialVersionUID = 1L;
		public String name;
		public String sex;
		public String age;
		public String stuno;
		public String clazz;
		public String faculty;
		public boolean equals(Object obj) {
		return equals((Student) obj);
		}
		public boolean equals(Student obj) {
		boolean isName = true;
		if (obj.name != null && !"".equals(obj.name)) {
		isName = name.equals(obj.name);
		}
		boolean isSex = true;
		if (obj.sex != null && !"".equals(obj.sex)) {
		isSex = sex.equals(obj.sex);
		}
		boolean isAge = true;
		if (obj.age != null && !"".equals(obj.age)) {
		isAge = age.equals(obj.age);
		}
		boolean isStuno = true;
		if (obj.stuno != null && !"".equals(obj.stuno)) {
		isStuno = stuno.equals(obj.stuno);
		}
		boolean isClazz = true;
		if (obj.clazz != null && !"".equals(obj.clazz)) {
		isClazz = clazz.equals(obj.clazz);
		}
		boolean isfaculty = true;
		if (obj.faculty != null && !"".equals(obj.faculty)) {
		isfaculty = faculty.equals(obj.faculty);
		}
		return isName && isSex && isAge && isStuno && isClazz && isfaculty;
		}
		public String[] toArray() {
		return new String[] { name, sex, age, stuno, clazz, faculty };
		}
	}

