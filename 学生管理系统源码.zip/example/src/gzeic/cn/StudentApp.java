package gzeic.cn;

	import java.awt.event.*;
	import java.util.*;
	import javax.swing.*;
	import javax.swing.table.DefaultTableModel;

	public class StudentApp extends JFrame {
		private static final long serialVersionUID = 1L;
		private JTextField nameField;
		private JTextField sexField;
		private JTextField ageField;
		private JTextField stunoField;
		private JTextField clazzField;
		private JTextField facultyField;
		private JTable table;
		private DefaultTableModel model;
		private String[] columns = { "����", "�Ա�", "����", "ѧ��", "�༶", "ϵ��" };
		private List data;
		private Student tmp;

		// �������Ա����䣬ѧ�ţ��༶��ϵ��
		public StudentApp() {
			data = new ArrayList();
			getContentPane().setLayout(null);
			JLabel lblName = new JLabel("����");
			lblName.setBounds(12, 10, 50, 13);
			getContentPane().add(lblName);
			nameField = new JTextField();
			nameField.setBounds(74, 7, 96, 19);
			getContentPane().add(nameField);
			nameField.setColumns(10);

			JLabel lblSex = new JLabel("�Ա�");
			lblSex.setBounds(182, 10, 50, 13);
			getContentPane().add(lblSex);
			sexField = new JTextField();
			sexField.setBounds(244, 7, 96, 19);
			getContentPane().add(sexField);
			sexField.setColumns(10);

			JLabel lblAge = new JLabel("����");
			lblAge.setBounds(352, 10, 50, 13);
			getContentPane().add(lblAge);
			ageField = new JTextField();
			ageField.setBounds(414, 7, 96, 19);
			getContentPane().add(ageField);
			ageField.setColumns(10);

			JLabel lblStuno = new JLabel("ѧ��");
			lblStuno.setBounds(12, 36, 50, 13);
			getContentPane().add(lblStuno);
			stunoField = new JTextField();
			stunoField.setColumns(10);
			stunoField.setBounds(74, 33, 96, 19);
			getContentPane().add(stunoField);

			JLabel lblClass = new JLabel("�༶");
			lblClass.setBounds(182, 36, 50, 13);
			getContentPane().add(lblClass);
			clazzField = new JTextField();
			clazzField.setColumns(10);
			clazzField.setBounds(244, 33, 96, 19);
			getContentPane().add(clazzField);

			JLabel lblFaculty = new JLabel("ϵ��");
			lblFaculty.setBounds(352, 36, 50, 13);
			getContentPane().add(lblFaculty);
			facultyField = new JTextField();
			facultyField.setColumns(10);
			facultyField.setBounds(414, 33, 96, 19);
			getContentPane().add(facultyField);
			JButton btnAdd = new JButton("add");

			btnAdd.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					add();
				}
			});
			btnAdd.setBounds(192, 59, 67, 21);
			getContentPane().add(btnAdd);
			JButton btnDel = new JButton("del");
			btnDel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					del();
				}
			});
			btnDel.setBounds(271, 59, 58, 21);
			getContentPane().add(btnDel);
			JButton btnUpdate = new JButton("update");
			btnUpdate.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					update();
				}
			});
			btnUpdate.setBounds(352, 59, 77, 21);
			getContentPane().add(btnUpdate);
			JButton btnFind = new JButton("find");
			btnFind.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					find();
				}
			});
			btnFind.setBounds(441, 59, 69, 21);
			getContentPane().add(btnFind);
			model = new DefaultTableModel(columns, 0);
			table = new JTable(model);
			table.addMouseListener(new MouseAdapter() {
				public void mouseClicked(MouseEvent e) {
					int row = table.getSelectedRow();
					nameField.setText((String) table.getValueAt(row, 0));
					sexField.setText((String) table.getValueAt(row, 1));
					ageField.setText((String) table.getValueAt(row, 2));
					stunoField.setText((String) table.getValueAt(row, 3));
					clazzField.setText((String) table.getValueAt(row, 4));
					facultyField.setText((String) table.getValueAt(row, 5));
					tmp = getInput();
				}
			});
			JScrollPane scrollPane = new JScrollPane(table);
			scrollPane.setBounds(12, 90, 571, 248);
			getContentPane().add(scrollPane);
			setDefaultCloseOperation(EXIT_ON_CLOSE);
			setLocationRelativeTo(null);
			setSize(601, 380);
			setResizable(false);
			setVisible(true);
		}

		private Student getInput() {
			Student stu = new Student();
			stu.name = nameField.getText();
			stu.sex = sexField.getText();
			stu.age = ageField.getText();
			stu.stuno = stunoField.getText();
			stu.clazz = clazzField.getText();
			stu.faculty = facultyField.getText();
			return stu;
		}

		private void add() {
			data.add(getInput());
			showTable();
		}

		private void del() {
			try {
				for (int i = 0; i < data.size(); i++) {
					if (tmp.equals(data.get(i))) {
						data.remove(i);
						break;
					}
				}
				showTable();
			} catch (Exception e) {
				System.out.println("��ȷ�������ݿ��޸�");
			}
		}

		private void update() {
			try {
				Student stu = getInput();
				for (int i = 0; i < data.size(); i++) {
					if (tmp.equals(data.get(i))) {
						data.remove(i);
						data.add(i, stu);
						break;
					}
				}
				showTable();
			} catch (Exception e) {
				System.out.println("��ȷ�������ݿ��޸�");
			}
		}

		private void find() {
			try {
				removeRows();
				Student stu = getInput();
				for (int i = 0; i < data.size(); i++) {
					Student tmp = (Student) data.get(i);
					if (tmp.equals(stu)) {
						model.addRow(tmp.toArray());
						break;
					}
				}
			} catch (Exception e) {
				System.out.println("��ȷ�������ݿ��޸�");
			}
		}

		private void showTable() {
			removeRows();
			for (int i = 0; i < data.size(); i++) {
				Student stu = (Student) data.get(i);
				model.addRow(stu.toArray());
			}
		}

		private void removeRows() {
			while (model.getRowCount() > 0) {
				model.removeRow(0);
			}
		}
	}


